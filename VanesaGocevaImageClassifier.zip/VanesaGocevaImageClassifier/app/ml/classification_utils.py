
def classify_image(model_id: str, img_id: str):
    # Dummy implementation
    return { "cat": 0.8, "dog": 0.2 }
