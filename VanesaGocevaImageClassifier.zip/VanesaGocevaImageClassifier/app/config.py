
class Configuration:
    models = ["resnet", "mobilenet", "vgg"]
